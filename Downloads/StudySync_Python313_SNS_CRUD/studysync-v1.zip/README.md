# StudySync — Digital Student Timer & Session Log
**CCP Project | Django 4.x | Python 3.13 | AWS SNS | AWS RDS PostgreSQL | AWS Elastic Beanstalk**

---

## Quick Start (Local Development)

```bash
# 1. Create virtual environment
python3.13 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set environment variables (copy and edit)
cp .env.example .env

# 4. Run migrations
python manage.py migrate

# 5. Create superuser
python manage.py createsuperuser

# 6. Run development server
python manage.py runserver
```

Open http://localhost:8000

---

## Project Structure

```
studysync/
├── studysync/          # Django project settings, urls, wsgi
├── timer/              # Main app: models, views, forms, urls, sns_service
├── studytimer_analytics/  # Custom pip library (4 OOP classes)
│   ├── timers.py       # SessionTimer
│   ├── aggregators.py  # ReportAggregator
│   ├── formatters.py   # DurationFormatter
│   └── evaluators.py   # StudyGoalEvaluator
├── templates/          # Django HTML templates (Bootstrap 5 + Chart.js)
├── static/             # CSS & JS assets
├── tests/              # pytest unit tests (≥70% coverage)
├── requirements.txt
├── Procfile            # Elastic Beanstalk / Gunicorn
└── .env.example        # Environment variable template
```

---

## Running Tests

```bash
pytest tests/ -v --cov=studytimer_analytics --cov-report=term-missing
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Backend | Django 4.x, Python 3.13 |
| Database | AWS RDS PostgreSQL |
| Frontend | Django Templates + Chart.js |
| Custom Library | studytimer_analytics (local pip) |
| Storage | AWS S3 (boto3) |
| Notifications | **AWS SNS (boto3)** |
| Deployment | AWS Elastic Beanstalk |
| CI/CD | AWS CodePipeline + CodeBuild |
| Monitoring | AWS CloudWatch |

---

## AWS SNS Notification Events

| Event | Topic | Requirement |
|---|---|---|
| Session started | Student topic | FR-12 |
| Session completed (with duration) | Student topic | FR-06, FR-12 |
| Daily goal achieved | Student topic | FR-12 |
| Weekly goal achieved | Student topic | FR-12 |
| Critical error / CloudWatch alarm | Admin topic | AR-04, NFR-07 |

---

## Key Features

- **Real-time timer** — persists across page refreshes (FR-05, NFR-05)
- **SNS notifications** — session events + goal achievements (FR-12)
- **Daily & weekly reports** — Chart.js bar charts (FR-07, FR-08)
- **Session history** — paginated, filterable (FR-09)
- **Data isolation** — all queries scoped to authenticated user (NFR-03)
- **Atomic session writes** — Django ORM transactions (NFR-08)
- **Bootstrap 5** — responsive 768px+ (NFR-13)
- **GDPR** — EU region eu-west-1 (NFR-14)
