"""
studytimer_analytics — Custom pip library for StudySync
Provides OOP analytics classes: SessionTimer, ReportAggregator,
DurationFormatter, StudyGoalEvaluator.
NFR-09: All classes follow OOP / single-responsibility principles with docstrings.
NFR-10: All four classes have dedicated unit tests achieving ≥70% coverage.
"""

from .timers import SessionTimer
from .aggregators import ReportAggregator
from .formatters import DurationFormatter
from .evaluators import StudyGoalEvaluator

__all__ = ['SessionTimer', 'ReportAggregator', 'DurationFormatter', 'StudyGoalEvaluator']
__version__ = '1.0.0'
