"""
studytimer_analytics.aggregators
Provides the ReportAggregator class for computing daily and weekly study reports.
"""

from datetime import date, timedelta
from collections import defaultdict
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from django.contrib.auth.models import User


class ReportAggregator:
    """
    Aggregates study session data for daily and weekly reports.

    Responsibilities:
    - Compute total study time per day/week (FR-07, FR-08)
    - Break down study time by subject
    - Calculate streaks and sessions completed
    - Enforce user-scoped queries (NFR-03)

    Usage:
        aggregator = ReportAggregator(user)
        daily = aggregator.daily_report(date.today())
        weekly = aggregator.weekly_report(date.today())
    """

    def __init__(self, user: 'User'):
        """
        Initialise the ReportAggregator.

        Args:
            user: The authenticated Django User. All queries are scoped to this user.
        """
        self._user = user

    def daily_report(self, report_date: date) -> dict:
        """
        Generate a daily study report for the given date (FR-07).

        Args:
            report_date: The date to generate the report for.

        Returns:
            Dict with keys:
                - total_seconds (int)
                - session_count (int)
                - avg_session_seconds (int)
                - subject_breakdown (dict: subject -> seconds)
        """
        from timer.models import StudySession
        sessions = StudySession.objects.filter(
            user=self._user,
            status=StudySession.STATUS_COMPLETED,
            started_at__date=report_date,
        )
        return self._aggregate_sessions(sessions)

    def weekly_report(self, end_date: date) -> dict:
        """
        Generate a rolling 7-day study report ending on end_date (FR-08).

        Args:
            end_date: The last day of the 7-day window.

        Returns:
            Dict with keys:
                - total_seconds (int)
                - session_count (int)
                - avg_session_seconds (int)
                - days_studied (int)
                - current_streak (int)
                - subject_breakdown (dict: subject -> seconds)
                - daily_labels (list of date strings)
                - daily_totals (list of seconds per day)
        """
        from timer.models import StudySession
        start_date = end_date - timedelta(days=6)
        sessions = StudySession.objects.filter(
            user=self._user,
            status=StudySession.STATUS_COMPLETED,
            started_at__date__gte=start_date,
            started_at__date__lte=end_date,
        )
        base = self._aggregate_sessions(sessions)

        # Daily breakdown for chart
        daily_map = defaultdict(int)
        for s in sessions:
            day_key = s.started_at.date()
            daily_map[day_key] += (s.duration_seconds or 0)

        daily_labels = []
        daily_totals = []
        for i in range(7):
            d = start_date + timedelta(days=i)
            daily_labels.append(d.strftime('%a %d/%m'))
            daily_totals.append(daily_map.get(d, 0))

        days_studied = sum(1 for t in daily_totals if t > 0)
        streak = self._calculate_streak(end_date)

        return {
            **base,
            'days_studied': days_studied,
            'current_streak': streak,
            'daily_labels': daily_labels,
            'daily_totals': daily_totals,
        }

    def _aggregate_sessions(self, sessions) -> dict:
        """Compute aggregate stats from a queryset of completed sessions."""
        total_seconds = 0
        subject_breakdown = defaultdict(int)
        session_list = list(sessions)

        for s in session_list:
            dur = s.duration_seconds or 0
            total_seconds += dur
            subject_breakdown[s.subject or 'General'] += dur

        count = len(session_list)
        avg = (total_seconds // count) if count > 0 else 0

        return {
            'total_seconds': total_seconds,
            'session_count': count,
            'avg_session_seconds': avg,
            'subject_breakdown': dict(subject_breakdown),
        }

    def _calculate_streak(self, from_date: date) -> int:
        """
        Calculate the current consecutive days studied streak.

        Args:
            from_date: The most recent date to check backwards from.

        Returns:
            Number of consecutive days with at least one completed session.
        """
        from timer.models import StudySession
        streak = 0
        check_date = from_date
        while True:
            has_session = StudySession.objects.filter(
                user=self._user,
                status=StudySession.STATUS_COMPLETED,
                started_at__date=check_date,
            ).exists()
            if not has_session:
                break
            streak += 1
            check_date -= timedelta(days=1)
        return streak
