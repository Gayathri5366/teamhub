"""
studytimer_analytics.evaluators
Provides the StudyGoalEvaluator class for evaluating study goal achievement.
"""


class StudyGoalEvaluator:
    """
    Evaluates whether a student has achieved their study goals.

    Responsibilities:
    - Determine if a daily or weekly goal has been met (FR-11, FR-12)
    - Calculate goal progress as a percentage
    - Determine remaining time needed to reach goal

    Usage:
        evaluator = StudyGoalEvaluator()
        evaluator.is_goal_achieved(minutes_studied=130, goal_minutes=120)  # -> True
        evaluator.progress_percent(90, 120)  # -> 75.0
        evaluator.remaining_minutes(90, 120)  # -> 30
    """

    def is_goal_achieved(self, minutes_studied: int, goal_minutes: int) -> bool:
        """
        Determine if the study goal has been achieved.

        Args:
            minutes_studied: Total minutes studied in the period.
            goal_minutes:    The goal target in minutes.

        Returns:
            True if minutes_studied >= goal_minutes and goal_minutes > 0.
        """
        if goal_minutes <= 0:
            return False
        return minutes_studied >= goal_minutes

    def progress_percent(self, minutes_studied: int, goal_minutes: int) -> float:
        """
        Calculate goal progress as a percentage (capped at 100%).

        Args:
            minutes_studied: Total minutes studied.
            goal_minutes:    The goal target in minutes.

        Returns:
            Float between 0.0 and 100.0.
        """
        if goal_minutes <= 0:
            return 0.0
        return min(100.0, round((minutes_studied / goal_minutes) * 100, 1))

    def remaining_minutes(self, minutes_studied: int, goal_minutes: int) -> int:
        """
        Calculate remaining minutes needed to reach the goal.

        Args:
            minutes_studied: Total minutes studied.
            goal_minutes:    The goal target in minutes.

        Returns:
            Remaining minutes (0 if goal already achieved).
        """
        return max(0, goal_minutes - minutes_studied)

    def evaluate(self, minutes_studied: int, goal_minutes: int) -> dict:
        """
        Return a full goal evaluation summary dict.

        Args:
            minutes_studied: Total minutes studied.
            goal_minutes:    The goal target in minutes.

        Returns:
            Dict with keys: achieved, progress_percent, remaining_minutes.
        """
        return {
            'achieved': self.is_goal_achieved(minutes_studied, goal_minutes),
            'progress_percent': self.progress_percent(minutes_studied, goal_minutes),
            'remaining_minutes': self.remaining_minutes(minutes_studied, goal_minutes),
        }
