"""
studytimer_analytics.timers
Provides the SessionTimer class for calculating elapsed time and session state.
"""

from datetime import datetime, timezone as dt_timezone
from typing import Optional


class SessionTimer:
    """
    Calculates elapsed time and session state for a study session.

    Responsibilities:
    - Track start/end timestamps
    - Calculate elapsed seconds accurately (NFR-05: ±1 second accuracy)
    - Determine if a session is active or completed

    Usage:
        timer = SessionTimer(started_at=session.started_at)
        elapsed = timer.elapsed_seconds()
        hms = timer.format_hms()
    """

    def __init__(self, started_at: datetime, ended_at: Optional[datetime] = None):
        """
        Initialise the SessionTimer.

        Args:
            started_at: The UTC datetime when the session started.
            ended_at:   The UTC datetime when the session ended (None if active).
        """
        self._started_at = self._ensure_utc(started_at)
        self._ended_at = self._ensure_utc(ended_at) if ended_at else None

    @staticmethod
    def _ensure_utc(dt: datetime) -> datetime:
        """Ensure datetime is timezone-aware (UTC)."""
        if dt.tzinfo is None:
            return dt.replace(tzinfo=dt_timezone.utc)
        return dt

    def is_active(self) -> bool:
        """Return True if the session is still running."""
        return self._ended_at is None

    def elapsed_seconds(self) -> int:
        """
        Calculate total elapsed seconds.

        Returns:
            Elapsed seconds as an integer. If session is active,
            calculates from now. If completed, uses ended_at.
        """
        end = self._ended_at if self._ended_at else datetime.now(dt_timezone.utc)
        delta = end - self._started_at
        return max(0, int(delta.total_seconds()))

    def elapsed_minutes(self) -> float:
        """Return elapsed time in fractional minutes."""
        return self.elapsed_seconds() / 60.0

    def format_hms(self) -> str:
        """
        Format elapsed time as HH:MM:SS string (FR-05).

        Returns:
            String in HH:MM:SS format, e.g. '01:23:45'.
        """
        total = self.elapsed_seconds()
        hours, remainder = divmod(total, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def started_at(self) -> datetime:
        """Return the session start datetime."""
        return self._started_at

    def ended_at(self) -> Optional[datetime]:
        """Return the session end datetime, or None if still active."""
        return self._ended_at
