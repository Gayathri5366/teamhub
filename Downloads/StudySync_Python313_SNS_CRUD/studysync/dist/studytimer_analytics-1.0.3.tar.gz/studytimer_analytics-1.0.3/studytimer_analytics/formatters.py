"""
studytimer_analytics.formatters
Provides the DurationFormatter class for human-readable time formatting.
"""


class DurationFormatter:
    """
    Formats duration values into human-readable strings.

    Responsibilities:
    - Convert seconds to HH:MM:SS
    - Convert seconds to human-readable text (e.g. "1 hr 23 min")
    - Format minutes into short display strings

    Usage:
        fmt = DurationFormatter()
        fmt.format_duration(3661)   # -> "1 hr 1 min 1 sec"
        fmt.format_hms(3661)        # -> "01:01:01"
        fmt.format_minutes(90)      # -> "1 hr 30 min"
    """

    def format_duration(self, total_seconds: int) -> str:
        """
        Convert seconds into a human-readable duration string.

        Args:
            total_seconds: Number of seconds to format.

        Returns:
            E.g. "2 hr 5 min 30 sec", "45 min 0 sec", "30 sec"
        """
        total_seconds = max(0, int(total_seconds))
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        parts = []
        if hours > 0:
            parts.append(f"{hours} hr")
        if minutes > 0 or hours > 0:
            parts.append(f"{minutes} min")
        parts.append(f"{seconds} sec")

        return ' '.join(parts)

    def format_hms(self, total_seconds: int) -> str:
        """
        Format seconds as HH:MM:SS string.

        Args:
            total_seconds: Number of seconds.

        Returns:
            String in HH:MM:SS format, e.g. '01:23:45'.
        """
        total_seconds = max(0, int(total_seconds))
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def format_minutes(self, total_minutes: int) -> str:
        """
        Format total minutes as a short human-readable string.

        Args:
            total_minutes: Number of minutes to format.

        Returns:
            E.g. "1 hr 30 min", "45 min", "0 min"
        """
        total_minutes = max(0, int(total_minutes))
        hours, minutes = divmod(total_minutes, 60)
        if hours > 0:
            return f"{hours} hr {minutes} min"
        return f"{minutes} min"

    def seconds_to_minutes(self, seconds: int) -> float:
        """Convert seconds to fractional minutes."""
        return max(0, seconds) / 60.0
